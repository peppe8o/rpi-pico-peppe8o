window.onload = function(){
     myDIV();
 }
function myDIV() {
  //this triggers only the text color
  document.getElementById("divChange").style.color="white";
  
  //use this to change background color
  document.getElementById("divChange").style.backgroundColor="red";
}